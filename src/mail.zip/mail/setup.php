﻿<?php
  $_SERVER = "http://localhost:3000"; // modo de teste local
  // $_SERVER = "https://srv.deliverybairro.com"; // modo de teste online (web)
  $thankyou   = "../thanks-msg.html"; // thank you page
  $email_to   = "ezequiasmartins@gmail.com"; 
  $email_from = "psi.software.adm@gmail.com";
  // if you update the question on the form - you need to update the questions answer below
  $antispam_answer = "21";
?>